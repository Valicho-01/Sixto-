<?php
return Illuminate\Foundation\Application::configure(basePath: dirname(__DIR__))->withRouting(web: __DIR__.'/../routes/web.php')->withMiddleware(function($middleware){})->withExceptions(function($exceptions){})->create();
