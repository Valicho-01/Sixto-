<?php
namespace Database\Seeders;
class DatabaseSeeder extends \Illuminate\Database\Seeder {public function run():void {foreach([['P01','Sándwich',500],['P02','Jugo',400],['P03','Café',300]] as [$c,$n,$p]) \App\Models\Producto::updateOrCreate(['codigo'=>$c],['nombre'=>$n,'precio'=>$p]);}}
