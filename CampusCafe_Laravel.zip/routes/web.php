<?php
use Illuminate\Support\Facades\Route;use App\Http\Controllers\CafeController;
Route::get('/',[CafeController::class,'index']);Route::post('/agregar',[CafeController::class,'agregar']);Route::post('/confirmar',[CafeController::class,'confirmar']);Route::post('/nuevo',[CafeController::class,'nuevo']);Route::get('/pruebas',[CafeController::class,'pruebas']);Route::post('/pruebas',[CafeController::class,'ejecutar']);Route::view('/xp','xp');
