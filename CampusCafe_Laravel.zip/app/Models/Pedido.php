<?php
namespace App\Models;
class Pedido extends \Illuminate\Database\Eloquent\Model {protected $table='pedidos'; protected $guarded=[]; public $timestamps=true; public function detalles(){return $this->hasMany(Detalle::class,'pedido_id');} }