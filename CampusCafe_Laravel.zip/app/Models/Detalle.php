<?php
namespace App\Models;
class Detalle extends \Illuminate\Database\Eloquent\Model {protected $table='detalle_pedido'; protected $guarded=[]; public $timestamps=false; public function producto(){return $this->belongsTo(Producto::class,'producto_id');} }