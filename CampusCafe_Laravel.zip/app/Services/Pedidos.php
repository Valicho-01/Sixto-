<?php
namespace App\Services;
use App\Models\{Pedido,Producto};
use Illuminate\Support\Facades\DB;
use DomainException;
class Pedidos {
 public function nuevo(int $i=2):Pedido {return Pedido::create(['iteracion'=>$i,'estado'=>'abierto','subtotal'=>0,'descuento'=>0,'total'=>0]);}
 public function agregar(Pedido $p,string $codigo,mixed $cantidad):Pedido {return DB::transaction(function()use($p,$codigo,$cantidad){$p=Pedido::findOrFail($p->id);if($p->estado!=='abierto')throw new DomainException('Pedido confirmado: cambios bloqueados.');if(!preg_match('/^[1-9][0-9]{0,5}$/D',(string)$cantidad))throw new DomainException('Cantidad inválida: debe ser un entero positivo.');$prod=Producto::where('codigo',$codigo)->first();if(!$prod)throw new DomainException('Producto inexistente.');$d=$p->detalles()->firstOrNew(['producto_id'=>$prod->id]);$d->cantidad=(int)$d->cantidad+(int)$cantidad;$d->precio_unitario=$prod->precio;$d->save();$p->update(Importe::calcular((int)$p->detalles()->selectRaw('SUM(cantidad * precio_unitario) as importe')->value('importe'),(int)$p->iteracion));return $p->refresh();});}
 public function confirmar(Pedido $p):Pedido {return DB::transaction(function()use($p){$p->refresh();if($p->iteracion!=2 || $p->estado!=='abierto'||!$p->detalles()->exists())throw new DomainException('No se puede confirmar este pedido.');$p->update(['estado'=>'confirmado']);return $p;});}
}
